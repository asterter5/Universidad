#include <iostream>
#include <vector>
#include "circulo.h"

using namespace std;

int main()
{
    int x = 8;
    int y = 2;

    Circulo c(x);

    Figura* c_p = &c;
    int suma1 = c.suma(y); // Accessing method from variable
    int suma2 = c_p->suma(y);

    /*
    Figura* f_p; // Figura* f_p = &f; // Another way to create pointer from variable
    f_p = new Figura(x); // Memory allocation

    f_p->suma(y); // Accessing method from pointer
    (*f_p).suma(y); // Accessing method from pointer content
    */

    // Circulo* circulos = new Circulo[4];
    // Circulo circulos[4]; <- Needed a default Constructor in order to create vectors
    // circulos[0].perimetro();

    Circulo* circulos[4]; // Array of pointers (like in C)

    for (int i = 0; i < 4; i++) {
        circulos[i] = new Circulo(x);
    }

    vector<Circulo*> v_circulos; // std C++ vector (with methods)

    for (int i = 0; i < 4; i++) {
        v_circulos.push_back(circulos[i]);
    }

    circulos[0]->perimetro();
    v_circulos[0]->perimetro();

    cout << "Hello World! " << endl;
    cout << "suma1 = " << suma1 << endl;
    cout << "suma2 = " << suma2 << endl;

    cout << "PERIMETRO: " << c_p->perimetro() << endl;

    for (int i = 0; i < 4; i++) {
        delete(circulos[i]);
    }
    //delete f_p; // Freeing memory
    return 0;
}

