#include "circulo.h"

Circulo::Circulo():Figura(0) // Default constructor (calls parent with value '0')
{

}

Circulo::Circulo(int x):Figura(x) // Calling parent constructor with child parameters
{

}

Circulo::~Circulo()
{

}

int Circulo::perimetro()
{
    return 10;
}
