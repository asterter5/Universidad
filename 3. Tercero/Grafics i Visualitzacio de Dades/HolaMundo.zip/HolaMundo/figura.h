#ifndef FIGURA_H
#define FIGURA_H

class Figura
{
public:
    int x;
    Figura(int x); // Constructor
    virtual ~Figura(); // Destructor (has to be overwritten in child class)

    int suma(int& y); // Method header declaration
    virtual int perimetro() = 0; // Abstract method declaration
};

#endif // FIGURA_H
