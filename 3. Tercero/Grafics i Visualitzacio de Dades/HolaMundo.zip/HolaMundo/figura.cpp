#include "figura.h"

Figura::Figura(int x)
{
    this->x = x;
}

Figura::~Figura()
{

}

int Figura::suma(int& y) {
    x += y;
    y++;
    return x;
}

