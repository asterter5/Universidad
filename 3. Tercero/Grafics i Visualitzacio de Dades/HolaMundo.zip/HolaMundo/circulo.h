#ifndef CIRCULO_H
#define CIRCULO_H

#include "figura.h"

class Circulo : public Figura
{
public:
    Circulo();
    Circulo(int x);
    ~Circulo();

    int perimetro();
};

#endif // CIRCULO_H
