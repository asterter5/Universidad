from __future__ import unicode_literals

from django.db import models

# Create your models here.

class Item(models.Model):
    description = models.CharField(max_length=400)
    name = models.CharField(max_length=40)
    type = models.CharField(max_length=3)
    price = models.FloatField(default=0)
    def __str__(self):
        return "["+self.type+"] "+ self.name

class Comment(models.Model):
	item = models.ForeignKey('Item', on_delete=models.CASCADE)
	content = models.CharField(max_length=140)
	def __str__(self):
		return ">>>"+self.content+"\n"
