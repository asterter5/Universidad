from django.shortcuts import render
from django.http import HttpResponse

from .models import Item

# Create your views here.

def index(request):
    return render(request, 'index.html')

def catalog(request, type):
    if (type == ""):
        catalog_by_type = Item.objects.all() 
    else:
        catalog_by_type = Item.objects.filter(type=type) 
    context = {
        'catalog':catalog_by_type,
        'type':type,
    }
    return render(request, 'mediacloud/catalog.html', context)

def item(request, id):
	item = Item.objects.get(pk=id)
	context = {
		'description': item.description,
		'name': item.name,
		'type': item.type,
		'price': item.price,
	}
	return render(request, 'mediacloud/item.html', context)