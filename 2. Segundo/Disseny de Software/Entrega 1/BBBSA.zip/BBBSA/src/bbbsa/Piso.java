/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bbbsa;

/**
 *
 * @author aprietde10.alumnes
 */
public class Piso {
    
    private String direccio;
    private String cp;
    private String poblacio;
    private long preu;
    private int nHabitacions;
    private int nBanys;
    private boolean terraza;
    private boolean oferta;

    public Piso() {
        this.direccio = "no";
        this.cp = "00000";
        this.poblacio = "BCN";
        this.preu = 0;
        this.nHabitacions = 0;
        this.nBanys = 0;
        this.terraza = false;
        this.oferta = false;
    }
    
    public Piso(String direccio, String cp, String poblacio, long preu, int nHabitacions, int nBanys, boolean terraza, boolean oferta) {
        this.direccio = direccio;
        this.cp = cp;
        this.poblacio = poblacio;
        this.preu = preu;
        this.nHabitacions = nHabitacions;
        this.nBanys = nBanys;
        this.terraza = terraza;
        this.oferta = oferta;
    }

    public String getDireccio() {
        return direccio;
    }

    public void setDireccio(String direccio) {
        this.direccio = direccio;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public String getPoblacio() {
        return poblacio;
    }

    public void setPoblacio(String poblacio) {
        this.poblacio = poblacio;
    }

    public long getPreu() {
        return preu;
    }

    public void setPreu(long preu) {
        this.preu = preu;
    }

    public int getnHabitacions() {
        return nHabitacions;
    }

    public void setnHabitacions(int nHabitacions) {
        this.nHabitacions = nHabitacions;
    }

    public int getnBanys() {
        return nBanys;
    }

    public void setnBanys(int nBanys) {
        this.nBanys = nBanys;
    }

    public boolean isTerraza() {
        return terraza;
    }

    public void setTerraza(boolean terraza) {
        this.terraza = terraza;
    }

    public boolean isOferta() {
        return oferta;
    }

    public void setOferta(boolean oferta) {
        this.oferta = oferta;
    }

    @Override
    public String toString() {
        return "Piso{" + direccio + ", " + cp + ", " + poblacio + "; preu=" + preu + ", nHabitacions=" + nHabitacions + ", nBanys=" + nBanys + ", terraza=" + terraza + '}';
    }
    
    
}
