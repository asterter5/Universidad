/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bbbsa;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author aprietde10.alumnes
 */
public class Menu <EnumTitulos extends Object>{
    
    EnumTitulos[] opcionesLista;
    String titulo;
    String[] descripciones;
    
    /**
     * Constructor de la classe Menu.
     * 
     * @param titulo
     * @param opcionesLista 
     */
    public Menu(String titulo, EnumTitulos[] opcionesLista) {
        this.titulo = titulo;
        this.opcionesLista = opcionesLista;
    }
    
    /**
     * Setter de les descripcions de cada opcio del menu.
     * 
     * @param descripciones 
     */
    public void setDescripciones(String[] descripciones) {
        this.descripciones = new String[descripciones.length];
        for(int i = 0; i < descripciones.length; i++){
            this.descripciones[i] = descripciones[i];
        }
    }
    
    /**
     * Metode que fa print del titol i de cada opcio del menu.
     */
    public void mostrarMenu() {
        System.out.println();
        System.out.println("****************************");
        System.out.println("       "+this.titulo);
        System.out.println("****************************");
        System.out.println();
        for(int i = 0; i < this.descripciones.length; ++i){
            System.out.print("[ "+(i+1)+" ] ");
            System.out.print(descripciones[i]+"\n");
        }
        System.out.println();
            
      
    }

    /**
     * Getter que recupera la opcio que marca l'usuari.
     * 
     * @param sc
     * @return 
     */
    public EnumTitulos getOpcion(Scanner sc) {
        System.out.print("Selecciona Opcio: ");   
        try{
            int n = sc.nextInt();
            if (n < 0 || n > opcionesLista.length){
                System.out.println("No existeix aquesta opcio!");
                return getOpcion(sc);
            }
            else return opcionesLista[n-1];
        } catch (InputMismatchException e){
            String n = sc.next();
            System.out.println("No existeix aquesta opcio!");
            return getOpcion(sc);
        }
       
   }

}
