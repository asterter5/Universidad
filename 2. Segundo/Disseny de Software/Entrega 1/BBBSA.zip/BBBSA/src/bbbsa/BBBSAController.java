/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bbbsa;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author aprietde10.alumnes
 */
public class BBBSAController {
    
    ArrayList<Client> lClients;
    ArrayList<Piso> lPisos;
    ArrayList<Visita> lVisites;

    public BBBSAController() {
        lClients = new ArrayList<>();
        lPisos = new ArrayList<>();
        lVisites = new ArrayList<>();
    }

    public BBBSAController(ArrayList<Client> lClients, ArrayList<Piso> lPisos, ArrayList<Visita> lVisites) {
        this.lClients = lClients;
        this.lPisos = lPisos;
        this.lVisites = lVisites;
    }

    public ArrayList<Client> getlClients() {
        return lClients;
    }

    public void setlClients(ArrayList<Client> lClients) {
        this.lClients = lClients;
    }

    public ArrayList<Piso> getlPisos() {
        return lPisos;
    }

    public void setlPisos(ArrayList<Piso> lPisos) {
        this.lPisos = lPisos;
    }

    public ArrayList<Visita> getlVisites() {
        return lVisites;
    }

    public void setlVisites(ArrayList<Visita> lVisites) {
        this.lVisites = lVisites;
    }
    
    /* METODES CLIENTS */
    
    public void mostrarClients() {
        System.out.println("Llista de clients:");
        if(this.lClients.isEmpty()){
            System.out.println("\nNo hi han clients!");
        } else {
            System.out.println();
            for(int i = 0; i < this.lClients.size(); i++){
                System.out.println("[ "+(i+1)+" ] "+this.lClients.get(i));
            }
        }
    }
    
    public void afegirClient() {
        Scanner sc = new Scanner(System.in);
        Client client = new Client();
        
        System.out.println("Nom del Client:");
        client.setNom(sc.nextLine());
        System.out.println("Cognom del Client: ");
        client.setCnom(sc.nextLine());
        System.out.println("Telf. del Client:");
        client.setTelf(sc.nextLine());
        System.out.println("eMail del Client:");
        client.setEmail(sc.nextLine());

        lClients.add(client);
    }
    
    public void actualitzarClient(Client client) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Actualitzar Nom (Enter per passar al seguent parametre): ");
        String nom = sc.nextLine();
        if (!nom.isEmpty()) {
            client.setNom(nom);
        }
        System.out.println("Actualitzar Cognom (Enter per passar al seguent parametre): ");
        String cognom = sc.nextLine();
        if (!cognom.isEmpty()) {
            client.setCnom(cognom);
        }
        System.out.println("Actualitzar Telefon (Enter per passar al seguent parametre):");
        String telf = sc.nextLine();
        if (!telf.isEmpty()) {
            client.setTelf(telf);
        }
        System.out.println("Actualitzar eMail (Enter per passar al seguent parametre): ");
        String email = sc.nextLine();
        if (!email.isEmpty()) {
            client.setEmail(email);
        }
    }
    
    public int buscarClients() {
        Scanner sc = new Scanner(System.in);
        ArrayList<Client> tmp = new ArrayList<>();
        String nom = "";
        int idx = 0;
        
        System.out.print("Buscar (Per nom): ");
        nom = sc.nextLine();
        for (int i = 0; i < lClients.size(); i++) {
            if (nom.equals(lClients.get(i).getNom())) {
                tmp.add(lClients.get(i));
            }
        }
        if (!tmp.isEmpty()){
            System.out.println("\nCoincidencies trobades:\n");
            for (int i = 0; i < tmp.size(); i++) {
                System.out.println("["+(i+1)+"]"+ tmp.get(i).toString());
            }
            System.out.print("\nSelecciona l'index del Client: ");
            idx = sc.nextInt();
        } else {
            System.out.println("\nNo s'han trobat coincidencies");
            idx = 0;
        }
        System.out.println();
        return idx-1;
    }
    
    public void mostrarClient(Client client) {
        System.out.println("\nNom: "+client.getNom()+"\nTelefon: "+client.getTelf()+"\neMail: "+client.getEmail()+"\n");
    }
    
    void eliminarClient(Client c) {
        if (lClients.contains(c)) {
            lClients.remove(c);
        }
    }
    
    /* METODES VISITES */
    
    public void mostrarVisites() {
        System.out.println("Llista de visites:");
        if(this.lVisites.isEmpty()){
            System.out.println("\nNo hi han visites!");
        } else {
            System.out.println();
            for(int i = 0; i < this.lVisites.size(); i++){
                System.out.println("[ "+(i+1)+" ]\n"+this.lVisites.get(i));
            }
        }
    }
 
    public void afegirVisita() {
        Scanner sc = new Scanner(System.in);
        int opcio = 1;
        
        System.out.println("Afegeix els parametres de la visita:\n ");
        switch(opcio) {
            case 1:
                if(!lClients.isEmpty()){
                    Visita v = new Visita();
                    System.out.println("Client de la Visita: ");
                    try {
                        v.setC(lClients.get(this.buscarClients()));
                    } catch (ArrayIndexOutOfBoundsException e){
                        System.out.println("No hi exiteix el client seleccionat");
                    }
                    System.out.println("Data de la Visita: ");
                    v.setData(sc.nextLine());
                    System.out.println("Hora de la Visita: ");
                    v.setHora(sc.nextLine());
                    System.out.println("Pis de la Visita: ");
                    try {
                        v.setP(lPisos.get(this.buscarPis()));
                    } catch (IndexOutOfBoundsException e){
                        System.out.println("No existeix el lloc seleccionat");
                    }
                    lVisites.add(v);
                } else {
                    System.out.println("No hi han clients amb qui concertar visites");
                }
                break;
             
            default:
                System.out.println("No has introduit un valor correcte!");
                break;
                
        }
    }
    
    public void actualitzarVisita(Visita v) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Actualitzar la data de la visita (Enter per passar al seguent parametre): ");
        String data = sc.nextLine();
        if (!data.isEmpty()) {
            v.setData(data);
        }
        System.out.println("Actualitzar l'hora de la visita (Enter per passar al seguent parametre): ");
        String hora = sc.nextLine();
        if (!hora.isEmpty()) {
            v.setHora(hora);
        }
        System.out.println("Actualitzar el Pis (Enter per finalitzar):");
        String ex = sc.nextLine();
        if (!ex.isEmpty()) {
            try {
                v.setP(lPisos.get(this.buscarPis()));
            } catch (ArrayIndexOutOfBoundsException e){

            }
        }
    }

    void mostrarVisita(Visita v) {   
        
        System.out.println("Persona: "+v.getC());
        System.out.println("Data: "+v.getData());
        System.out.println("Hora: "+v.getHora());
        System.out.println("Lloc: "+v.getP());
        
    }
    
    void eliminarVisita(Visita v) {
        if (lVisites.contains(v)) {
            lVisites.remove(v);
        }
    }
    
    /* METODES PISOS */
    
    public void mostrarLlocs() {
        System.out.println("\n");
        System.out.println("Llista de pisos:");
        if(this.lPisos.isEmpty()){
            System.out.println("\nNo hi han pisos!");
        } else {
            System.out.println();
            for(int i = 0; i < this.lPisos.size(); i++){
                System.out.println("[ "+(i+1)+" ] "+this.lPisos.get(i));
            }
        }
    }
    
    public void afegirLloc() {
        Scanner sc = new Scanner(System.in);
        Piso p = new Piso();
        
        System.out.println("Direccio:");
        p.setDireccio(sc.nextLine());
        System.out.println("Codi Postal: ");
        p.setCp(sc.nextLine());
        System.out.println("Poblacio: ");
        p.setPoblacio(sc.nextLine());
        System.out.println("preu del Pis: ");
        p.setPreu(sc.nextInt());
        System.out.println("nombre de Habitacions: ");
        p.setnHabitacions(sc.nextInt());
        System.out.println("nombre de Banys: ");
        p.setnBanys(sc.nextInt());
        System.out.println("Te Terrasa? (Y/N): ");
        if (sc.next().equals("Y")) {
            p.setTerraza(true);
        } else {
            p.setTerraza(false);
        }
        
        lPisos.add(p);
    }
    
    public void actualitzarLloc(Piso p) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Actualitzar el Preu del Pis: ");
        String preu = sc.nextLine();
        if (!preu.isEmpty()) {
            p.setPreu(Integer.parseInt(preu));
        }
        System.out.println("Pis en oferta? (Y/N): ");
        String oferta = sc.nextLine();
        if (oferta.equals("Y")) {
            if (!oferta.isEmpty()) {
            p.setOferta(true);
            }
        } else {
            if (!oferta.isEmpty()) {
            p.setOferta(false);
            }
        }
        
    }
    
    public int buscarPis() {
        Scanner sc = new Scanner(System.in);
        ArrayList<Piso> tmp = new ArrayList<>();
        String dir = "";
        int idx = 0;
        
        System.out.print("Buscar (Direccio): ");
        dir = sc.nextLine();
        for (int i = 0; i < lPisos.size(); i++) {
            if (dir.equals(lPisos.get(i).getDireccio())) {
                tmp.add(lPisos.get(i));
            }
        }
        
        if (!tmp.isEmpty()){
            System.out.println("\nCoincidencies trobades:\n");
            for (int i = 0; i < tmp.size(); i++) {
                System.out.println("["+(i+1)+"]"+ tmp.get(i).toString());
            }
            System.out.print("\nSelecciona l'index del Lloc: ");
            idx = sc.nextInt();
        } else {
            System.out.println("\nNo s'han trobat coincidencies");
            idx = 0;
        }
        System.out.println();
        return idx-1;
    }
    
    void mostrarPis(Piso get) {
        System.out.println(get);
    }
    
    public void eliminarPis(Piso lloc){
        if (lPisos.contains(lloc)) {
            lPisos.remove(lloc);
        }
    }
    
}
