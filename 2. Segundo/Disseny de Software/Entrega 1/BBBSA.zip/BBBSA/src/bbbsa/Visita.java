/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bbbsa;

/**
 *
 * @author aprietde10.alumnes
 */
public class Visita {
    
    private Client c;
    private Piso p;
    private String hora;
    private String data;

    public Visita() {
        this.c = new Client();
        this.p = new Piso();
        this.hora = "00:00";
        this.data = "01/01/2000";
    }

    public Visita(Client c, Piso p, String h, String d) {
        this.c = c;
        this.p = p;
        this.hora = h;
        this.data = d;
    }

    public Client getC() {
        return c;
    }

    public void setC(Client c) {
        this.c = c;
    }

    public Piso getP() {
        return p;
    }

    public void setP(Piso p) {
        this.p = p;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
    
    
}
