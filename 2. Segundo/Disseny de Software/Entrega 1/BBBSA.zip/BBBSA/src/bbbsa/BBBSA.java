/*
 * TODO: Mostrar la llista de pisos en oferta
 * TODO: Si la visita es erronia, que no continui demanant dades
 */
package bbbsa;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author aprietde10.alumnes
 */
public class BBBSA {
    
    BBBSAController ctrlM = new BBBSAController();

    static private enum OpcionsMenuPrincipal {

        GESTIONAR_CLIENTS, GESTIONAR_PISOS, GESTIONAR_VISITES, SORTIR
    }

    static private enum OpcionsMenuGestionarClients {

        AFEGIR_CLIENT, ACTUALITZAR_CLIENT, CONSULTAR_CLIENT, ELIMINAR_CLIENT, ENDARRERA
    }
    
    static private enum OpcionsMenuGestionarPisos {

        AFEGIR_PIS, ACTUALITZAR_PIS, CONSULTAR_PIS, ELIMINAR_PIS, ENDARRERA
    }
    
    static private enum OpcionsMenuGestionarVisita {

        AFEGIR_VISITA, ACTUALITZAR_VISITA, CONSULTAR_VISITA, ELIMINAR_VISITA, ENDARRERA
    }

    static private enum OpcionsMenuConsultarClients {

        TOTS, CONCRET, ENDARRERA
    }

    static private enum OpcionsMenuConsultarVisites {

        TOTS, CONCRET, ENDARRERA
    }

    static private enum OpcionsMenuConsultarLlocs {

        TOTS, CONCRET, EN_OFERTA, ENDARRERA
    }
    
    static private String[] descMenuPrincipal = {
        "Gestionar Clients",
        "Gestionar Pisos",
        "Gestionar Visites",
        "Sortir de l'aplicacio"};

    static private String[] descMenuGestionarClients = {
        "Afegir Client",
        "Actualitzar Client",
        "Consultar Clients",
        "Eliminar Client",
        "Endarrera"};
    
    static private String[] descMenuGestionarPisos = {
        "Afegir Pis",
        "Actualitzar Pis",
        "Consultar Pisos",
        "Eliminar Pis",
        "Endarrera"};
    
    static private String[] descMenuGestionarVisites = {
        "Afegir Visita",
        "Actualitzar Visita",
        "Consultar Visites",
        "Eliminar Visita",
        "Endarrera"};
    
    static private String[] descMenuConsultarClients = {
        "Tots els clients",
        "Client concret",
        "Endarrera"};
    
    static private String[] descMenuConsultarVisites = {
        "Totes les visites",
        "Visita concreta",
        "Endarrera"};
    
    static private String[] descMenuConsultarPisos = {
        "Tots els Pisos",
        "Pis concret",
        "En Oferta!", 
        "Endarrera"};
    
    public static void main(String[] args) {
        BBBSA bbb = new BBBSA();
        Scanner sc = new Scanner(System.in);
        bbb.menuPrincipal(sc);
    }
    
    private void menuPrincipal(Scanner sc) {
        Menu<BBBSA.OpcionsMenuPrincipal> menu = new Menu("Menu Principal", BBBSA.OpcionsMenuPrincipal.values());
        menu.setDescripciones(descMenuPrincipal);
        BBBSA.OpcionsMenuPrincipal opcion = null;
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case GESTIONAR_CLIENTS:
                    menuGestioClients(sc);
                    break;

                case GESTIONAR_VISITES:
                    menuGestioVisites(sc);
                    break;

                case GESTIONAR_PISOS:
                    menuGestioPisos(sc);
                    break;
                    
                case SORTIR:
                    System.out.println("Tancant...");
                    break;

            }
        } while (opcion != OpcionsMenuPrincipal.SORTIR);
    }
    
    private void menuGestioClients(Scanner sc) {
        Menu<BBBSA.OpcionsMenuGestionarClients> menu = new Menu("Gestionar Clients", BBBSA.OpcionsMenuGestionarClients.values());
        menu.setDescripciones(descMenuGestionarClients);
        BBBSA.OpcionsMenuGestionarClients opcion = null;
        int idx = 0;
        ArrayList<Client> tmp = ctrlM.getlClients();
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case AFEGIR_CLIENT:
                    ctrlM.afegirClient();
                    break;

                case ACTUALITZAR_CLIENT:
                    System.out.print("\nSelecciona el mètode de búsqueda:\n\n[ 1 ] Buscar per nom complet\n[ 2 ] Buscar per llista\n\n");
                    tmp = ctrlM.getlClients();
                    idx = 0;
                    try {
                        idx = sc.nextInt();
                    } catch (InputMismatchException IME) {
                        System.out.println("No has introduit un numero!");
                    }
                    System.out.println();
                    if (idx == 1) {
                        if(!tmp.isEmpty()){
                            int cl;
                            cl = ctrlM.buscarClients();
                            try {
                                ctrlM.actualitzarClient(tmp.get(cl));
                            } catch (IndexOutOfBoundsException e){
                                System.out.println("No existeix el client a actualitzar");
                            }
                        } else {
                            System.out.println("No hi han clients");
                        }
                    } else if (idx == 2) {
                        if(!tmp.isEmpty()){
                            ctrlM.mostrarClients();
                            System.out.print("\nSel.lecciona l'index del client a actualitzar: ");
                            try {
                                ctrlM.actualitzarClient(tmp.get(sc.nextInt() - 1));
                            } catch (IndexOutOfBoundsException e){
                                System.out.println("No existeix el client a actualitzar");
                            }
                        } else {
                            System.out.println("No hi han clients");
                        }
                    } else {
                        System.out.println("No has introduit un valor correcte!");
                    }
                    break;

                case CONSULTAR_CLIENT:                    
                    menuConsultarClients(sc);
                    break;

                case ELIMINAR_CLIENT:
                    System.out.print("\nSelecciona el mètode de búsqueda:\n\n[ 1 ] Buscar per nom\n[ 2 ] Buscar per llista\n\n");
                    tmp = ctrlM.getlClients();
                    idx = 0;
                    try {
                        idx = sc.nextInt();
                    } catch (InputMismatchException IME) {
                        System.out.println("No has introduit un numero!");
                    }
                    if (idx == 1) {
                        if(!tmp.isEmpty()){
                            int cl;
                            cl = ctrlM.buscarClients();
                            try {
                                ctrlM.eliminarClient(tmp.get(cl));
                            } catch (IndexOutOfBoundsException e){
                                System.out.println("No existeix el client a eliminar");
                            }
                        } else {
                            System.out.println("No hi han clients");
                        }
                    } else if (idx == 2) {
                        if(!tmp.isEmpty()){
                            System.out.println();
                            ctrlM.mostrarClients();
                            System.out.print("\nSel.lecciona l'index del client a eliminar: ");
                            try {
                                ctrlM.eliminarClient(tmp.get(sc.nextInt() - 1));
                            } catch (ArrayIndexOutOfBoundsException e){
                                System.out.println("No existeix el client a eliminar");
                            }
                        } else {
                            System.out.println("No hi han clients");
                        }
                    } else {
                        System.out.println("No has introduit un valor correcte!");
                    }
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsMenuGestionarClients.ENDARRERA);
    }
    
    private void menuGestioVisites(Scanner sc) {
        Menu<BBBSA.OpcionsMenuGestionarVisita> menu = new Menu("Gestionar Visites", BBBSA.OpcionsMenuGestionarVisita.values());
        menu.setDescripciones(descMenuGestionarVisites);
        BBBSA.OpcionsMenuGestionarVisita opcion = null;
        ArrayList<Visita> tmp = ctrlM.getlVisites();
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case AFEGIR_VISITA:
                    ctrlM.afegirVisita();
                    break;

                case ACTUALITZAR_VISITA:
                    tmp = ctrlM.getlVisites();
                    if(!tmp.isEmpty()){
                        ctrlM.mostrarVisites();
                        System.out.print("\nSel.lecciona l'index de la cita a actualitzar: ");
                        try {
                            ctrlM.actualitzarVisita(tmp.get(sc.nextInt() - 1));
                        } catch (IndexOutOfBoundsException e){
                            System.out.println("No existeix la cita a actualitzar");
                        }
                    } else {
                        System.out.println("No hi han cites");
                    }
                    break;

                case CONSULTAR_VISITA:
                    menuConsultarVisites(sc);
                    break;

                case ELIMINAR_VISITA:
                    tmp = ctrlM.getlVisites();
                    if(!tmp.isEmpty()){
                        ctrlM.mostrarVisites();
                        System.out.print("\nSel.lecciona l'index de la cita a eliminar: ");
                        try {
                            ctrlM.eliminarVisita(tmp.get(sc.nextInt() - 1));
                        } catch (IndexOutOfBoundsException e){
                            System.out.println("No existeix la cita a eliminar");
                        }
                    } else {
                        System.out.println("No hi han cites");
                    }
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsMenuGestionarVisita.ENDARRERA);
    }
    
    private void menuGestioPisos(Scanner sc) {
        Menu<BBBSA.OpcionsMenuGestionarPisos> menu = new Menu("Gestionar Llocs", BBBSA.OpcionsMenuGestionarPisos.values());
        menu.setDescripciones(descMenuGestionarPisos);
        BBBSA.OpcionsMenuGestionarPisos opcion = null;
        ArrayList<Piso> tmp = ctrlM.getlPisos();
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case AFEGIR_PIS:
                    ctrlM.afegirLloc();
                    break;

                case ACTUALITZAR_PIS:
                    tmp = ctrlM.getlPisos();
                    if(!tmp.isEmpty()){
                        ctrlM.mostrarLlocs();
                        System.out.print("\nSel.lecciona l'index del lloc a actualitzar: ");
                        try {
                            ctrlM.actualitzarLloc(tmp.get(sc.nextInt() - 1));
                        } catch (IndexOutOfBoundsException e){
                            System.out.println("No existeix el lloc a actualitzar");
                        }
                    } else {
                        System.out.println("No hi han llocs on anar");
                    }
                    break;

                case CONSULTAR_PIS:
                    menuConsultarPisos(sc);
                    break;

                case ELIMINAR_PIS:
                    tmp = ctrlM.getlPisos();
                    if(!tmp.isEmpty()){
                        ctrlM.mostrarLlocs();
                        System.out.print("\nSel.lecciona l'index del lloc a eliminar: ");
                        try {
                            ctrlM.eliminarPis(tmp.get(sc.nextInt() - 1));
                        } catch (IndexOutOfBoundsException e){
                            System.out.println("No existeix el lloc a eliminar");
                        }
                    } else {
                        System.out.println("No hi han llocs on anar");
                    }
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsMenuGestionarPisos.ENDARRERA);
    }
    
    private void menuConsultarClients(Scanner sc) {
        Menu<BBBSA.OpcionsMenuConsultarClients> menu = new Menu("Consultar Clients", BBBSA.OpcionsMenuConsultarClients.values());
        menu.setDescripciones(descMenuConsultarClients);
        BBBSA.OpcionsMenuConsultarClients opcion = null;
        ArrayList<Client> tmp = ctrlM.getlClients();
        int idx = 0;
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case TOTS:
                    ctrlM.mostrarClients();
                    break;

                case CONCRET:
                    if( !tmp.isEmpty()){
                        System.out.print("\nSelecciona el mètode de búsqueda:\n\n[ 1 ] Buscar per nom complet\n[ 2 ] Buscar per llista\n\n");
                        tmp = ctrlM.getlClients();
                        idx = 0;
                        try {
                            idx = sc.nextInt();
                        } catch (InputMismatchException IME) {
                            System.out.println("No has introduit un numero!");
                        }
                        if (idx == 1) {
                            int cl;
                            cl = ctrlM.buscarClients();
                            try {
                                ctrlM.mostrarClient(tmp.get(cl));
                            } catch (ArrayIndexOutOfBoundsException e){
                                System.out.println("No has introduit un valor correcte!");
                            }
                        } else if (idx == 2) {
                            ctrlM.mostrarClients();
                            System.out.print("Sel.lecciona l'index del client a consultar: ");
                            try {
                                ctrlM.mostrarClient(tmp.get(sc.nextInt() - 1));
                            } catch (IndexOutOfBoundsException e){
                                System.out.println("No has introduit un valor correcte!");
                            }
                        } else {
                            System.out.println("No has introduit un valor correcte!");
                        }
                    } else {
                        System.out.println("\nNo hi han clients!");
                    }
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsMenuConsultarClients.ENDARRERA);
    }
    
    private void menuConsultarVisites(Scanner sc) {
        Menu<BBBSA.OpcionsMenuConsultarVisites> menu = new Menu("Consultar Visites", BBBSA.OpcionsMenuConsultarVisites.values());
        menu.setDescripciones(descMenuConsultarVisites);
        BBBSA.OpcionsMenuConsultarVisites opcion = null;
        ArrayList<Visita> tmp = ctrlM.getlVisites();
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case TOTS:
                    ctrlM.mostrarVisites();
                    break;

                case CONCRET:
                    if(!tmp.isEmpty()){
                        tmp = ctrlM.getlVisites();
                        ctrlM.mostrarVisites();
                        System.out.print("Sel.lecciona l'index de la visita a consultar: ");
                        try {
                            ctrlM.mostrarVisita(tmp.get(sc.nextInt() - 1));
                        } catch (IndexOutOfBoundsException e){
                            System.out.println("No has introduit un valor correcte!");
                        }
                    } else {
                        System.out.println("\nNo hi han Visites!");
                    }
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsMenuConsultarVisites.ENDARRERA);
    }
    
    private void menuConsultarPisos(Scanner sc) {
        Menu<BBBSA.OpcionsMenuConsultarLlocs> menu = new Menu("Consultar Pisos", BBBSA.OpcionsMenuConsultarLlocs.values());
        menu.setDescripciones(descMenuConsultarPisos);
        BBBSA.OpcionsMenuConsultarLlocs opcion = null;
        ArrayList<Piso> tmp = ctrlM.getlPisos();
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case TOTS:
                    ctrlM.mostrarLlocs();
                    break;

                case CONCRET:
                    if(!tmp.isEmpty()){
                        tmp = ctrlM.getlPisos();
                        ctrlM.mostrarLlocs();
                        System.out.print("Sel.lecciona l'index del pis a consultar: ");
                        try {
                            ctrlM.mostrarPis(tmp.get(sc.nextInt() - 1));
                        } catch (IndexOutOfBoundsException e){
                            System.out.println("No has introduit un valor correcte!");
                        }
                    } else {
                        System.out.println("\nNo hi han Pisos favorits!");
                    }
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsMenuConsultarLlocs.ENDARRERA);
    }
    
}
