/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motorentalsa.Model;

/**
 *
 * @author aprietde10.alumnes
 */
public class Vehicle {
    
    private String model;
    private String color;
    private String ID;
    private boolean isTaken;
    
    public Vehicle() {
        this.model = "";
        this.color = "";
        this.ID = "";
        this.isTaken = false;  
    }
    
    public Vehicle(String m, String c, String i, boolean t) {
        this.model = m;
        this.color = c;
        this.ID = i;
        this.isTaken = t; 
    }
    
}
