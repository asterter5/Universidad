/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motorentalsa.Model;

/**
 *
 * @author aprietde10.alumnes
 */
public class Gerent extends Persona {
    
    private String uniqueID;
    
    public Gerent() {
        super();
        this.uniqueID = "";
    }

    public Gerent(String n, String c, String u) {
        super(n, c);
        this.uniqueID = u;
    }
 
}
