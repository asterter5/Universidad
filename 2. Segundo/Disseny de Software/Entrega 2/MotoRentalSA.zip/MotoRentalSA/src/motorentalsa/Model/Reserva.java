/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motorentalsa.Model;

/**
 *
 * @author aprietde10.alumnes
 */
public class Reserva {
    
    private int timeSec;
    private String codiReserva;

    public Reserva() {
        this.timeSec = 0;
        this.codiReserva = "";
    }

    public Reserva(int t, String c) {
        this.timeSec = t;
        this.codiReserva = c;
    }
    
}
