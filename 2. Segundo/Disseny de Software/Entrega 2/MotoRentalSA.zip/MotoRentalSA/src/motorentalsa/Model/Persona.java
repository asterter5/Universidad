/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motorentalsa.Model;

/**
 *
 * @author aprietde10.alumnes
 */
public class Persona {
    
    private String nom;
    private String cognom;
    
    public Persona() {
        this.nom = "";
        this.cognom = "";
    }

    public Persona(String n, String c) {
        this.nom = n;
        this.cognom = c;
    }
    
}
