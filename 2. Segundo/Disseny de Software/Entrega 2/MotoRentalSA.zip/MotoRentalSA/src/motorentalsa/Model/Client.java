/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motorentalsa.Model;

/**
 *
 * @author aprietde10.alumnes
 */
public class Client extends Persona {
 
    private String DNI;
    private String telefon;
    private boolean isVip;
    private boolean conteBank;
    
    public Client() {
        super();
        this.DNI = "";
        this.telefon = "";
        this.isVip = false;
        this.conteBank = false;
    }

    public Client(String n, String c, String d, String t, boolean iv, boolean cb) {
        super(n, c);
        this.DNI = d;
        this.telefon = t;
        this.isVip = iv;
        this.conteBank = cb;
    }
    
}
