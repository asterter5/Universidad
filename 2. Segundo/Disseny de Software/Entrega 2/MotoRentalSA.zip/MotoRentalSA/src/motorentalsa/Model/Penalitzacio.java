/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motorentalsa.Model;

/**
 *
 * @author aprietde10.alumnes
 */
public class Penalitzacio {
    
    private float cost;
    
    public Penalitzacio(){
        this.cost = 0.0f;
    }
    
    public Penalitzacio(float c) {
        this.cost = c;
    }
    
}
