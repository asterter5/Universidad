
package motorentalsa.Vista;
     
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import motorentalsa.Controlador.*;

/**
 *
 * @author aprietde10.alumnes
 */
public class MotoRentalSA {
    
    MRSAController ctrlM = new MRSAController();
    String cliente[] = {"astor", "1234", "true"};
    String gerente[] = {"quim", "1234", "false"};

    static private enum OpcionsMenuLogin {

        LOG_IN, REGISTRARSE, SORTIR
    }

    static private enum OpcionsMenuClients {

        RESERVAR_MOTO, MODIFICAR_RESERVA, COMPROVAR_LOCAL, DONAR_BAIXA, SORTIR
    }
    
    static private enum OpcionsMenuGerent {

        COMPROVAR_RESERVA, CLIENTS_VIP, GESTIONAR_PENALITZACIONS, GESTIONAR_MOTOS, SORTIR
    }
    
    static private enum OpcionsSubmenuVIP {

        DONAR_ALTA, DONAR_BAIXA, CONSULTAR_STATUS, ENDARRERA
    }

    static private enum OpcionsSubmenuPenalitzacio {

        CREAR_PENALITZACIO, TANCAR_PENALITZACIO, ENDARRERA
    }

    static private enum OpcionsSubmenuMotos {

        DEMANAR_MOTOS, TRANSFERIR_MOTOS, ENDARRERA
    }
    
    static private String[] descMenuLogin = {
        "Log-In",
        "Registrar-se",
        "Sortir de l'aplicacio"};

    static private String[] descMenuClients = {
        "Reservar una Moto",
        "Modificar una Reserva",
        "Comprovar motos en un Local",
        "Donar-se de baixa",
        "Sortir de l'aplicacio"};
    
    static private String[] descMenuGerent = {
        "Comprovar una Reserva",
        "Gestionar clients VIP",
        "Gestionar Penalitzacions",
        "Gestionar motos del Local",
        "Sortir de l'aplicacio"};
    
    static private String[] descSubmenuVIP = {
        "Donar de alta un Client",
        "Donar de baixa un Client",
        "Consultar el descompte d'un client",
        "Endarrera"};
    
    static private String[] descSubmenuPenalitzacions = {
        "Crear una Penalitzacio",
        "Tancar una Penalitzacio",
        "Endarrera"};
    
    static private String[] descSubmenuMotos = {
        "Demanar motos a altres Locals",
        "Transferir motos a altres Locals",
        "Endarrera"};
    
    public static void main(String[] args) {
        MotoRentalSA mrsa = new MotoRentalSA();
        Scanner sc = new Scanner(System.in);
        mrsa.menuPrincipal(sc);
    }
    
    private void menuPrincipal(Scanner sc) {
        Menu<MotoRentalSA.OpcionsMenuLogin> menu = new Menu("Menu Principal", MotoRentalSA.OpcionsMenuLogin.values());
        menu.setDescripciones(descMenuLogin);
        MotoRentalSA.OpcionsMenuLogin opcion = null;
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case LOG_IN:
                    String user;
                    String pass;
                    
                    System.out.println("Introdueix el teu usuari:");
                    user = sc.next();
                    
                    System.out.println("Introdueix la teva contassenya:");
                    pass = sc.next();
                    
                    if(user.equals(cliente[0]) && (pass.equals(cliente[1]))) {
                        System.out.println("Log-In Succesfull! [1]");
                        menuClients(sc);
                        break;
                    } if(user.equals(gerente[0]) && (pass.equals(gerente[1]))) {
                        System.out.println("Log-In Succesfull! [2]");
                        menuGerent(sc);
                        break;
                    } else {
                        System.err.println("Failed to Log-In...");
                        break;
                    }

                case REGISTRARSE:
                    System.out.println("Registrar-se! [TODO]");
                    break;
                    
                case SORTIR:
                    System.out.println("Tancant l'Aplicacio...");
                    break;

            }
        } while (opcion != OpcionsMenuLogin.SORTIR);
    }
    
    private void menuClients(Scanner sc) {
        Menu<MotoRentalSA.OpcionsMenuClients> menu = new Menu("Menu Clients", MotoRentalSA.OpcionsMenuClients.values());
        menu.setDescripciones(descMenuClients);
        MotoRentalSA.OpcionsMenuClients opcion = null;
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case RESERVAR_MOTO:
                    System.out.println("Reservar Moto! [TODO]");
                    break;

                case MODIFICAR_RESERVA:
                    System.out.println("Modificar Reserva! [TODO]");
                    break;

                case COMPROVAR_LOCAL:                    
                    System.out.println("Comprovar Local! [TODO]");
                    break;
                    
                case DONAR_BAIXA:
                    System.out.println("Donar-se de Baixa! [TODO]");
                    break;
                    
                case SORTIR:
                    System.out.println("Tancant Sessio...");
                    break;
            }
        } while (opcion != OpcionsMenuClients.SORTIR);
    }
    
    private void menuGerent(Scanner sc) {
        Menu<MotoRentalSA.OpcionsMenuGerent> menu = new Menu("Menu Gerent", MotoRentalSA.OpcionsMenuGerent.values());
        menu.setDescripciones(descMenuGerent);
        MotoRentalSA.OpcionsMenuGerent opcion = null;
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case COMPROVAR_RESERVA:
                    System.out.println("Comprovar Reserva! [TODO]");
                    break;

                case CLIENTS_VIP:
                    menuSubVIP(sc);
                    break;

                case GESTIONAR_PENALITZACIONS:
                    menuSubPenalitzacions(sc);
                    break;

                case GESTIONAR_MOTOS:
                    menuSubMotos(sc);
                    break;

                case SORTIR:
                    System.out.println("Tancant Sessio...");
                    break;

            }
        } while (opcion != OpcionsMenuGerent.SORTIR);
    }
    
    private void menuSubVIP(Scanner sc) {
        Menu<MotoRentalSA.OpcionsSubmenuVIP> menu = new Menu("Gestionar Clients VIP", MotoRentalSA.OpcionsSubmenuVIP.values());
        menu.setDescripciones(descSubmenuVIP);
        MotoRentalSA.OpcionsSubmenuVIP opcion = null;
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case DONAR_ALTA:
                    System.out.println("Donar Alta VIP! [TODO]");
                    break;

                case DONAR_BAIXA:
                    System.out.println("Donar Baixa VIP! [TODO]");
                    break;

                case CONSULTAR_STATUS:
                    System.out.println("Consultar Status Client! [TODO]");
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsSubmenuVIP.ENDARRERA);
    }
    
    private void menuSubPenalitzacions(Scanner sc) {
        Menu<MotoRentalSA.OpcionsSubmenuPenalitzacio> menu = new Menu("Gestionar Penalitzacions", MotoRentalSA.OpcionsSubmenuPenalitzacio.values());
        menu.setDescripciones(descSubmenuPenalitzacions);
        MotoRentalSA.OpcionsSubmenuPenalitzacio opcion = null;
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case CREAR_PENALITZACIO:
                    System.out.println("Crear Penalitzacio! [TODO]");
                    break;

                case TANCAR_PENALITZACIO:
                    System.out.println("Tancar Penalitzacio! [TODO]");
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsSubmenuPenalitzacio.ENDARRERA);
    }
    
    private void menuSubMotos(Scanner sc) {
        Menu<MotoRentalSA.OpcionsSubmenuMotos> menu = new Menu("Consultar Visites", MotoRentalSA.OpcionsSubmenuMotos.values());
        menu.setDescripciones(descSubmenuMotos);
        MotoRentalSA.OpcionsSubmenuMotos opcion = null;
        do {
            menu.mostrarMenu();
            opcion = menu.getOpcion(sc);
            switch (opcion) {

                case DEMANAR_MOTOS:
                    System.out.println("Demanar Motos a altres Locals! [TODO]");
                    break;

                case TRANSFERIR_MOTOS:
                    System.out.println("Transferir Motos a altres Locals! [TODO]");
                    break;

                case ENDARRERA:
                    System.out.println("Tornant al menú anterior");
                    break;

            }
        } while (opcion != OpcionsSubmenuMotos.ENDARRERA);
    }
    
}
