/*
 *  kernel/kernel.c
 *
 *  Minikernel. Versi�n 1.0
 *
 *  Fernando P�rez Costoya
 *
 */

/*
 *
 * Fichero que contiene la funcionalidad del sistema operativo
 *
 */

#include "kernel.h"	/* Contiene defs. usadas por este modulo */

/*
 *
 * Funciones relacionadas con la tabla de procesos:
 *	iniciar_tabla_proc buscar_BCP_libre
 *
 */

/*
 * Funci�n que inicia la tabla de procesos
 */
static void iniciar_tabla_proc(){
	int i;

	for (i=0; i<MAX_PROC; i++)
		tabla_procs[i].estado=NO_USADA;
}

/*
 * Funci�n que busca una entrada libre en la tabla de procesos
 */
static int buscar_BCP_libre(){
	int i;

	for (i=0; i<MAX_PROC; i++)
		if (tabla_procs[i].estado==NO_USADA)
			return i;
	return -1;
}

/*
 * Funcion que muestra datos de un BCP
 */

static int muestra_lista(lista_BCPs * lista){
	BCP *paux=lista->primero;

	while(paux->siguiente!=NULL){
		printk("-> Proc ID: %d / Estado: %d / Ticks: %d\n", paux->id, paux->estado, paux->ticks);
		paux=paux->siguiente;
	}
	return 0;

}

/*
 *
 * Funciones que facilitan el manejo de las listas de BCPs
 *	insertar_ultimo eliminar_primero eliminar_elem
 *
 * NOTA: PRIMERO SE DEBE LLAMAR A eliminar Y LUEGO A insertar
 */

/*
 * Inserta un BCP al final de la lista.
 */
static void insertar_ultimo(lista_BCPs *lista, BCP * proc){
	if (lista->primero==NULL)
		lista->primero= proc;
	else
		lista->ultimo->siguiente=proc;
	lista->ultimo= proc;
	proc->siguiente=NULL;
}

/*
 * Inserta un BCP el segundo de la lista.
 */
static void insertar_segundo(lista_BCPs *lista, BCP * proc){
	if (lista->primero==NULL) {
		lista->primero = proc;
	} if (lista->primero!=NULL && lista->ultimo==NULL) {
		lista->primero->siguiente = proc;
		lista->ultimo = proc;
	} else {
		proc->siguiente=lista->primero->siguiente;
		lista->primero->siguiente=proc;
	}
}

/*
 * Elimina el primer BCP de la lista.
 */
static void eliminar_primero(lista_BCPs *lista){

	if (lista->ultimo==lista->primero)
		lista->ultimo=NULL;
	lista->primero=lista->primero->siguiente;
}

/*
 * Elimina un determinado BCP de la lista.
 */
static void eliminar_elem(lista_BCPs *lista, BCP * proc){
	BCP *paux=lista->primero;

	if (paux==proc)
		eliminar_primero(lista);
	else {
		for ( ; ((paux) && (paux->siguiente!=proc));
			paux=paux->siguiente);
		if (paux) {
			if (lista->ultimo==paux->siguiente)
				lista->ultimo=paux;
			paux->siguiente=paux->siguiente->siguiente;
		}
	}
}

/*
 *
 * Funciones relacionadas con la planificacion
 *	espera_int planificador
 */

/*
 * Espera a que se produzca una interrupcion
 */
static void espera_int(){
	int nivel;

	printk("-> NO HAY LISTOS. ESPERA INT. ULTIMO PROC. LISTO: %d \n", p_proc_actual->id);

	/* Baja al m�nimo el nivel de interrupci�n mientras espera */
	nivel=fijar_nivel_int(NIVEL_1);
	halt();
	fijar_nivel_int(nivel);
}

/*
 * Funci�n de planificacion que implementa un algoritmo FIFO.
 */
static BCP * planificador(){
	while (lista_listos.primero==NULL)
		espera_int();		/* No hay nada que hacer */
	return lista_listos.primero;
}

/*
 * Funcion para cambiar el proceso en cualquier caso (Bloqueo, Final o Involuntario).
 */
static void cambio_proceso(lista_BCPs * lista){
	int nivel;

	nivel=fijar_nivel_int(NIVEL_3);
	eliminar_primero(&lista_listos); /* proc. fuera de listos */
		
	if (lista != NULL){
		insertar_ultimo(lista, p_proc_actual);	/* proc. entra en dormidos */
	} fijar_nivel_int(nivel);
	
	/* Realizar cambio de contexto */
	p_proc_anterior=p_proc_actual;
    	p_proc_actual=planificador();
    	p_proc_actual->estado=EJECUCION;

	if (lista == NULL) {
		liberar_pila(p_proc_anterior->pila);
		cambio_contexto(NULL, &(p_proc_actual->contexto_regs));
	}
	else {
		cambio_contexto(&(p_proc_anterior->contexto_regs), &(p_proc_actual->contexto_regs));
	}
}

/*
 * Bloquea un proceso y lo borra de lista_listos
 */
static void bloquear(lista_BCPs * lista){

        p_proc_actual->estado=BLOQUEADO;
        cambio_proceso(lista);

        printk("-> C.CONTEXTO POR FIN: de %d a %d\n",
                        p_proc_anterior->id, p_proc_actual->id);

        return; /* no deber�a llegar aqui */

}

/*
 * Desbloquea un proceso y lo incluye en lista_listos
 */
static void desbloquear(BCP * proc, lista_BCPs * lista){
        int nivel;

        proc->estado=LISTO;
        nivel=fijar_nivel_int(NIVEL_3);
        eliminar_elem(lista, proc); /* proc. fuera de dormidos */
        if (proc->rodaja == 0)
                insertar_ultimo(&lista_listos, proc); /* proc. dentro de listos */
        else
                p_proc_actual->rodaja=TICKS_POR_RODAJA;
                insertar_segundo(&lista_listos, proc); /* proc. dentro de listos */
        fijar_nivel_int(nivel);

        return;
}

/*
 * Mira si se han acabado los hijos de un proceso y los trata
 */
static void tratar_padre(){
        BCP *paux=lista_espera.primero;

        while(paux!=NULL){
                if(paux->num_hijos==0){
                        desbloquear(paux, &(lista_espera));
                }
                paux = paux->siguiente;
        }
}

/*
 *
 * Funcion auxiliar que termina proceso actual liberando sus recursos.
 * Usada por llamada terminar_proceso y por rutinas que tratan excepciones
 *
 */
static void liberar_proceso(){
	int i;
	BCP *p_padre = &tabla_procs[p_proc_actual->pid];

	liberar_imagen(p_proc_actual->info_mem); /* liberar mapa */

	/* comprobamos los hijos del proc. que acaba, y si queda alguno huerfano, lo adopta el proc. init */
	if(p_proc_actual->num_hijos != 0) {
		for(i=1; i<MAX_PROC; i++) {
			if(p_proc_actual->id==tabla_procs[i].pid) {
				tabla_procs[i].pid=lista_espera.primero->id;
				lista_espera.primero->num_hijos++;
			}
		} 
	}

	/* Restamos el proc. que acaba del padre */
	if(p_padre!=NULL){
		p_padre->num_hijos--;
	}

	tratar_padre();

	p_proc_actual->estado=TERMINADO;
	cambio_proceso(NULL);

	printk("-> C.CONTEXTO POR FIN: de %d a %d\n",
			p_proc_anterior->id, p_proc_actual->id);

	return; /* no deber�a llegar aqui */
}

/*
 * Reajusta los ticks de lista_dormidos en cada int_reloj
 */
static void ajustar_dormidos(){
        BCP *paux=lista_dormidos.primero;
	BCP *psalvado;

        while(paux!=NULL){
                paux->ticks=paux->ticks-1;
		psalvado=paux->siguiente;
                if(paux->ticks==0){
                        desbloquear(paux, &(lista_dormidos));               
		} paux=psalvado;
        }

}

/*
 * Actualiza el parametro rodaja del proceso en ejecucion
 */
static void actualizar_rodaja(){
	if (p_proc_actual->estado == EJECUCION) {
		if (p_proc_actual->rodaja == 0){
			replanificacion_pendiente = 1;
			activar_int_SW();
		} else {
			p_proc_actual->rodaja--;
		}
	}
}

/*
 *
 * Funciones relacionadas con el tratamiento de interrupciones
 *	excepciones: exc_arit exc_mem
 *	interrupciones de reloj: int_reloj
 *	interrupciones del terminal: int_terminal
 *	llamadas al sistemas: llam_sis
 *	interrupciones SW: int_sw
 *
 */

/*
 * Tratamiento de excepciones aritmeticas
 */
static void exc_arit(){

	if (!viene_de_modo_usuario())
		panico("excepcion aritmetica cuando estaba dentro del kernel");


	printk("-> EXCEPCION ARITMETICA EN PROC %d\n", p_proc_actual->id);
	liberar_proceso();

        return; /* no deber�a llegar aqui */
}

/*
 * Tratamiento de excepciones en el acceso a memoria
 */
static void exc_mem(){

	if (!viene_de_modo_usuario())
		panico("excepcion de memoria cuando estaba dentro del kernel");


	printk("-> EXCEPCION DE MEMORIA EN PROC %d\n", p_proc_actual->id);
	liberar_proceso();

        return; /* no deber�a llegar aqui */
}

/*
 * Tratamiento de interrupciones de terminal
 */
static void int_terminal(){

	printk("-> TRATANDO INT. DE TERMINAL %c\n", leer_puerto(DIR_TERMINAL));

        return;
}

/*
 * Tratamiento de interrupciones de reloj
 */
static void int_reloj(){

	printk("-> TRATANDO INT. DE RELOJ\n");
	 
	actualizar_rodaja();
	ajustar_dormidos();
	tratar_padre();

    return;
}

/*
 * Tratamiento de llamadas al sistema
 */
static void tratar_llamsis(){
	int nserv, res;

	nserv=leer_registro(0);
	if (nserv<NSERVICIOS)
		res=(tabla_servicios[nserv].fservicio)();
	else
		res=-1;		/* servicio no existente */
	escribir_registro(0,res);
	return;
}

/*
 * Tratamiento de interrupciuones software
 */
static void int_sw(){

	printk("-> TRATANDO INT. SW\n");
	
	if (replanificacion_pendiente){
		if (p_proc_actual->siguiente == NULL) {
			p_proc_actual->rodaja=TICKS_POR_RODAJA;
			cambio_proceso(&lista_listos); 	/* cambio de proceso a listos */
		} 
		else if (p_proc_actual->siguiente != NULL && p_proc_actual->vueltas < 2) {
			p_proc_actual->rodaja= (1/2)*TICKS_POR_RODAJA;
			p_proc_actual->vueltas++;
			cambio_proceso(&lista_listos); 	/* cambio de proceso a listos */
		} 
		else if (p_proc_actual->siguiente != NULL && p_proc_actual->vueltas >= 2) {
			p_proc_actual->ticks = (3/4)*TICKS_POR_RODAJA;
			p_proc_actual->vueltas = 0;
			bloquear(&(lista_dormidos));
		}

		replanificacion_pendiente = 0;
	}
	
	return;
}

/*
 *
 * Funcion auxiliar que crea un proceso reservando sus recursos.
 * Usada por llamada crear_proceso.
 *
 */
static int crear_tarea(char *prog){
	void * imagen, *pc_inicial;
	int error=0;
	int proc;
	int nivel;
	BCP *p_proc;

	proc=buscar_BCP_libre();
	if (proc==-1)
		return -1;	/* no hay entrada libre */

	/* A rellenar el BCP ... */
	p_proc=&(tabla_procs[proc]);

	/* crea la imagen de memoria leyendo ejecutable */
	imagen=crear_imagen(prog, &pc_inicial);
	if (imagen)
	{
		p_proc->info_mem=imagen;
		p_proc->pila=crear_pila(TAM_PILA);
		fijar_contexto_ini(p_proc->info_mem, p_proc->pila, TAM_PILA,
			pc_inicial,
			&(p_proc->contexto_regs));
		p_proc->id=proc;
		p_proc->estado=LISTO;
		p_proc->rodaja=TICKS_POR_RODAJA;
		p_proc->vueltas=0;
		p_proc->num_hijos=0;

		if (p_proc_actual==NULL) {
                        p_proc->pid=-1;
                } 
		else {
                        p_proc->pid=p_proc_actual->id;
                        p_proc_actual->num_hijos++;
                }

		/* lo inserta al final de cola de listos */
		nivel=fijar_nivel_int(NIVEL_3);
		insertar_ultimo(&lista_listos, p_proc);
		fijar_nivel_int(nivel);
		error= 0;
	}
	else
		error= -1; /* fallo al crear imagen */

	return error;
}

/*
 *
 * Rutinas que llevan a cabo las llamadas al sistema
 *	sis_crear_proceso sis_escribir
 *
 */

/*
 * Tratamiento de llamada al sistema crear_proceso. Llama a la
 * funcion auxiliar crear_tarea sis_terminar_proceso
 */
int sis_crear_proceso(){
	char *prog;
	int res;

	printk("-> PROC %d: CREAR PROCESO\n", p_proc_actual->id);
	prog=(char *)leer_registro(1);
	res=crear_tarea(prog);
	return res;
}

/*
 * Tratamiento de llamada al sistema escribir. Llama simplemente a la
 * funcion de apoyo escribir_ker
 */
int sis_escribir()
{
	char *texto;
	unsigned int longi;

	texto=(char *)leer_registro(1);
	longi=(unsigned int)leer_registro(2);

	escribir_ker(texto, longi);
	return 0;
}

/*
 * Tratamiento de llamada al sistema terminar_proceso. Llama a la
 * funcion auxiliar liberar_proceso
 */
int sis_terminar_proceso(){

	printk("-> FIN PROCESO %d\n", p_proc_actual->id);

	liberar_proceso();

        return 0; /* no deber�a llegar aqui */
}

int sis_nueva();

/*
 * Tratamiento de la llamada al sistema dormir. Manda a un
 * proceso a dormir
 */

int sis_dormir(){
	int segs;

	segs = leer_registro(1);
	p_proc_actual->ticks=segs*TICK;

	printk("-> BLOQUEANDO PROCESO %d POR %d SEGS\n", p_proc_actual->id, segs);

	replanificacion_pendiente = 0;
	bloquear(&(lista_dormidos));

	return 0;
}

/*
 * Tratamiento de la llamada al sistema get_pid.
 * Funcion que devuelve el ID de un Proceso.
 */

int sis_get_pid(){
        return p_proc_actual->id;
}

/*
 * Tratamiento de la llamada al sistema get_ppid.
 * Funcion que devuelve el ID del padre de un proceso.
 */

int sis_get_ppid(){
        return p_proc_actual->pid;
}

/*
 * Tratamiento de la llamada al sistema espera.
 * Funcion que espera a que todos los hijos del proceso acaben para acabar.
 * retornara 0 cuando se acaben de ejecutar los hijos, o -1 si no tiene hijos.
 */

int sis_espera(){

	printk("-> ESPERANDO A QUE LOS HIJOS DE PROC. %d FINALICEN\n", p_proc_actual->id);

	if(p_proc_actual->num_hijos==0){
		return -1;
	} else {
		bloquear(&(lista_espera));
		return 0;
	}
}

/*
 *
 * Rutina de inicializaci�n invocada en arranque
 *
 */

int main(){
	/* se llega con las interrupciones prohibidas */
	iniciar_tabla_proc();

	instal_man_int(EXC_ARITM, exc_arit); 
	instal_man_int(EXC_MEM, exc_mem); 
	instal_man_int(INT_RELOJ, int_reloj); 
	instal_man_int(INT_TERMINAL, int_terminal); 
	instal_man_int(LLAM_SIS, tratar_llamsis); 
	instal_man_int(INT_SW, int_sw); 

	iniciar_cont_int();		/* inicia cont. interr. */
	iniciar_cont_reloj(TICK);	/* fija frecuencia del reloj */
	iniciar_cont_teclado();		/* inici cont. teclado */
	
	printk("Creo el init desde el main de kernel.c\n");

	/* crea proceso inicial */
	if (crear_tarea((void *)"init")<0)
		panico("no encontrado el proceso inicial");
	
	/* activa proceso inicial */
	p_proc_actual=planificador();
	p_proc_actual->estado=EJECUCION;
	cambio_contexto(NULL, &(p_proc_actual->contexto_regs));
	panico("S.O. reactivado inesperadamente");
	return 0;}
