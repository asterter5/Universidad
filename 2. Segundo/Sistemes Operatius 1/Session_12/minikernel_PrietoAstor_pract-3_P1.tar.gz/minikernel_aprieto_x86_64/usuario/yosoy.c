/*
 *  usuario/yosoy.c
 *
 *  Minikernel. Versión 1.0
 *
 *  Fernando Pérez Costoya
 *
 */

/*
 * Programa de usuario que imprime muchas veces su ID
 */

#include "servicios.h"

#define TOT_ITER 10000 /* ponga las que considere oportuno */

int main(){
        int i;

        for (i=0; i<TOT_ITER; i++)
                printf("yosoy: i %d\n", i);
        	printf("Mi ID de Proceso es: %d\n", get_pid());

        printf("yosoy: termina\n");
        return 0;
}

