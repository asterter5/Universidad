/*  usuario/dormilon.c
 *
 *  Minikernel. Versión 1.0
 *
 *  Fernando Pérez Costoya
 *
 */

/*
 * Programa de usuario que manda a dormir al proceso
 */

#include "servicios.h"

int main(){

        dormir(3);

        return 0;
}

